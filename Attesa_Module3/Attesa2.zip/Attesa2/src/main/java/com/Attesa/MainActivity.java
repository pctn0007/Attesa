package com.Attesa;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private View view;
    private ListView mDrawerList;
    private DrawerLayout mDrawerLayout;
    private ArrayAdapter<String> mAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mActivityTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDrawerList = (ListView)findViewById(R.id.navList);
        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        mActivityTitle = getTitle().toString();

        addDrawerItems();
        setupDrawer();
        setupList();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

    }

    private void setupList()
    {

        // @Note: We setup a for-loop here in order to fetch all records and create
        final Button clinic = (Button)findViewById(R.id.button);
        final Button clinic2 = (Button)findViewById(R.id.button2);
        final Button clinic3 = (Button)findViewById(R.id.button3);
        final Button clinic4 = (Button)findViewById(R.id.button4);

        final TextView txtcname = (TextView)findViewById(R.id.txtCName1);
        final TextView txtcname2 = (TextView)findViewById(R.id.txtCName2);
        final TextView txtcname3 = (TextView)findViewById(R.id.txtCName3);
        final TextView txtcname4 = (TextView)findViewById(R.id.txtCName4);

        final TextView txtcloc = (TextView)findViewById(R.id.txtLocation1);
        final TextView txtcloc2 = (TextView)findViewById(R.id.txtLocation2);
        final TextView txtcloc3 = (TextView)findViewById(R.id.txtLocation3);
        final TextView txtcloc4 = (TextView)findViewById(R.id.txtLocation4);

        final TextView txtctype = (TextView)findViewById(R.id.txtCType1);
        final TextView txtctype2 = (TextView)findViewById(R.id.txtCType2);
        final TextView txtctype3 = (TextView)findViewById(R.id.txtCType3);
        final TextView txtctype4 = (TextView)findViewById(R.id.txtCType4);

        final TextView txtcwait = (TextView)findViewById(R.id.txtAvgWait1);
        final TextView txtcwait2 = (TextView)findViewById(R.id.txtAvgWait2);
        final TextView txtcwait3 = (TextView)findViewById(R.id.txtAvgWait3);
        final TextView txtcwait4 = (TextView)findViewById(R.id.txtAvgWait4);

        // Fake clinic 1 select...
        clinic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cnamestr = txtcname.getText().toString();
                String clocstr = txtcloc.getText().toString();
                String ctypestr = txtctype.getText().toString();
                String clivestr = clinic.getText().toString();
                String cwaitstr = txtcwait.getBackground().toString();

                Intent myIntent = new Intent(MainActivity.this, BookActivity.class);
                myIntent.putExtra("cname", cnamestr);
                myIntent.putExtra("cloc", clocstr);
                myIntent.putExtra("ctype", ctypestr);
                myIntent.putExtra("clive", clivestr);
                myIntent.putExtra("cwait", cwaitstr);

                startActivity(myIntent);
            }
        });
        // Fake clinic 2 select...
        clinic2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cnamestr = txtcname2.getText().toString();
                String clocstr = txtcloc2.getText().toString();
                String ctypestr = txtctype2.getText().toString();
                String clivestr = clinic2.getText().toString();
                String cwaitstr = txtcwait2.getBackground().toString();

                Intent myIntent = new Intent(MainActivity.this, BookActivity.class);
                myIntent.putExtra("cname", cnamestr);
                myIntent.putExtra("cloc", clocstr);
                myIntent.putExtra("ctype", ctypestr);
                myIntent.putExtra("clive", clivestr);
                myIntent.putExtra("cwait", cwaitstr);

                startActivity(myIntent);
            }
        });
        // Fake clinic 3 select...
        clinic3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cnamestr = txtcname3.getText().toString();
                String clocstr = txtcloc3.getText().toString();
                String ctypestr = txtctype3.getText().toString();
                String clivestr = clinic3.getText().toString();
                String cwaitstr = txtcwait3.getBackground().toString();


                Intent myIntent = new Intent(MainActivity.this, BookActivity.class);
                myIntent.putExtra("cname", cnamestr);
                myIntent.putExtra("cloc", clocstr);
                myIntent.putExtra("ctype", ctypestr);
                myIntent.putExtra("clive", clivestr);
                myIntent.putExtra("cwait", cwaitstr);

                startActivity(myIntent);
            }
        });
        // Fake clinic 4 select...
        clinic4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cnamestr = txtcname4.getText().toString();
                String clocstr = txtcloc4.getText().toString();
                String ctypestr = txtctype4.getText().toString();
                String clivestr = clinic4.getText().toString();
                String cwaitstr = txtcwait4.getBackground().toString();

                Intent myIntent = new Intent(MainActivity.this, BookActivity.class);
                myIntent.putExtra("cname", cnamestr);
                myIntent.putExtra("cloc", clocstr);
                myIntent.putExtra("ctype", ctypestr);
                myIntent.putExtra("clive", clivestr);
                myIntent.putExtra("cwait", cwaitstr);

                startActivity(myIntent);
            }
        });


    }



    private void addDrawerItems() {
        String[] osArray = { "Profile", "Settings", "Help", "Sign out" };
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, osArray);
        mDrawerList.setAdapter(mAdapter);

        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "Test!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getSupportActionBar().setTitle("Hi, Anthony");
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                getSupportActionBar().setTitle(mActivityTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

     /*
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
    */
        // Activate the navigation drawer toggle
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}