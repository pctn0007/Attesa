package com.Attesa;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SummaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        Toast.makeText(SummaryActivity.this, "Show position in line and LIVE wait time.", Toast.LENGTH_SHORT).show();

        cancelVisit();

    }

    private void cancelVisit()
    {
        Button btnCancel = (Button)findViewById(R.id.btnCancel);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SummaryActivity.this, "Canceling visit.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }

}
