package com.Attesa;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegActivity extends AppCompatActivity {

    /*
        Author: Anthony Pacitto
        Application: Attesa
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);


        regSubmit();
    }

    private void regSubmit()
    {

        final EditText etFName = (EditText)findViewById(R.id.editFName);
        final EditText etLName = (EditText)findViewById(R.id.editLName);
        final EditText etOHIP = (EditText)findViewById(R.id.editOHIP);
        final EditText etEmail = (EditText)findViewById(R.id.editEmail);
        final EditText etPass = (EditText)findViewById(R.id.editPass);
        final TextView txtErr = (TextView)findViewById(R.id.txtRegerror);
        final CheckBox chkTerms = (CheckBox)findViewById(R.id.chkTerms);
        Button btnReg = (Button)findViewById(R.id.btnRegisterSubmit);

        // Test data
        final String email = "test@gmail.com";
        final String pass = "1234";


        btnReg.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                // check blank fields
                if (etFName.getText().toString().equals("") ||
                        etLName.getText().toString().equals("") ||
                        etEmail.getText().toString().equals("") ||
                        etPass.getText().toString().equals("") ||
                        etOHIP.getText().toString().equals("")) {

                    txtErr.setText("Oops! All fields must be filled in.");
                    txtErr.setVisibility(View.VISIBLE);
                }
                else if (!chkTerms.isChecked())
                {
                    txtErr.setText("You must agree to the terms and conditions.");
                    txtErr.setVisibility(View.VISIBLE);

                }
                // check ohip exists.
                else if (etOHIP.length() != 10)
                {
                    txtErr.setText("Oops! Please enter a valid Health Card Number.");
                    txtErr.setVisibility(View.VISIBLE);
                }
                else
                {
                    // Everything checks out... (CRUD: INSERT into table_name...)
                    txtErr.setText("");
                    txtErr.setVisibility(View.GONE);
                    Toast.makeText(RegActivity.this, "SQL: perform register check(s) here!", Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(RegActivity.this, MainActivity.class);
                    startActivity(myIntent);
                }
            }
        });


    }

}
