package com.Attesa;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class BookActivity extends AppCompatActivity {

    /*
        Author: Dariusz
        Application: Attesa
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        setupClinic();

    }

  private void setupClinic()
  {
      Button btnCheckin = (Button)findViewById(R.id.btnCheckin);

      TextView txtcname = (TextView)findViewById(R.id.txtCName1);
      TextView txtcloc = (TextView) findViewById(R.id.txtLocation1);
      TextView txtctype = (TextView) findViewById(R.id.txtCType1);
      Button txtclive = (Button) findViewById(R.id.button);
      TextView txtcwait = (TextView) findViewById(R.id.txtAvgWait1);

      String cname = getIntent().getExtras().getString("cname");
      String cloc = getIntent().getExtras().getString("cloc");
      String ctype = getIntent().getExtras().getString("ctype");
      String clive = getIntent().getExtras().getString("clive");
      String cwait = getIntent().getExtras().getString("cwait");

      txtcname.setText(cname);
      txtcloc.setText(cloc);
      txtctype.setText(ctype);
      txtclive.setText(clive);
      txtcwait.setText(cwait);

      btnCheckin.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent myIntent = new Intent(BookActivity.this, SummaryActivity.class);
              startActivity(myIntent);
          }
      });

  }
}
