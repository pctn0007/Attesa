package com.Attesa;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class BookActivity extends AppCompatActivity {

    /*
        Author: Dariusz
        Application: Attesa
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        setupClinic();
        backSubmit();
    }

  private void setupClinic()
  {
      Button btnCheckin = (Button)findViewById(R.id.btnCheckin);

      TextView txtcname = (TextView)findViewById(R.id.txtCName1);
      TextView txtcloc = (TextView) findViewById(R.id.txtLocation1);
      TextView txtctype = (TextView) findViewById(R.id.txtCType1);
      Button txtclive = (Button) findViewById(R.id.button);
      TextView txtcwait = (TextView) findViewById(R.id.txtAvgWait1);

      String cname = getIntent().getExtras().getString("cname");
      String cloc = getIntent().getExtras().getString("cloc");
      String ctype = getIntent().getExtras().getString("ctype");
      String clive = getIntent().getExtras().getString("clive");
      String cwait = getIntent().getExtras().getString("cwait"); // @Note: BUG here?? Display "android" instead of passed string.

      // Determine color code of Live time via clive data passed via prior activity.
      // @Note: Experiencing slight lag here??
      if (clive.equals("12"))
      {
          txtclive.setBackgroundResource(R.drawable.round_bg_button);
      }
      else
      {
          if (clive.equals("25"))
          {
              txtclive.setBackgroundResource(R.drawable.round_bg_button_orange);
          }
          else
          {
              txtclive.setBackgroundResource(R.drawable.round_bg_button_red);
          }
      }

      txtcname.setText(cname);
      txtcloc.setText(cloc);
      txtctype.setText(ctype);
      txtclive.setText(clive);
      txtcwait.setText(cwait);

      btnCheckin.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent myIntent = new Intent(BookActivity.this, SummaryActivity.class);
              startActivity(myIntent);
          }
      });

  }

  private void backSubmit()
  {
      ImageButton btnBackSubmit = (ImageButton)findViewById(R.id.btnCustBack);
      btnBackSubmit.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent myIntent = new Intent(BookActivity.this, MainActivity.class);
              startActivity(myIntent);
          }
      });
  }




}
