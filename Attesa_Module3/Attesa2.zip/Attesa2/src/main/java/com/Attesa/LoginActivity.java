package com.Attesa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    /*
        Author: Anthony Pacitto
        Application: Attesa
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginSubmit();

    }

    private void loginSubmit()
    {

        final EditText etEmail = (EditText)findViewById(R.id.editEmail);
        final EditText etPass = (EditText)findViewById(R.id.editPass);
        final TextView txtErr = (TextView)findViewById(R.id.txterror);
        Button btnLogin = (Button)findViewById(R.id.btnLoginSubmit);

        // Test data
        final String email = "test@gmail.com";
        final String pass = "1";


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.equals(etEmail.getText().toString()) && pass.equals(etPass.getText().toString())) {
                    txtErr.setVisibility(View.GONE);
                    Toast.makeText(LoginActivity.this, "SQL: perform login check here!", Toast.LENGTH_SHORT).show();
                     Intent myIntent = new Intent(LoginActivity.this, MainActivity.class);
                     startActivity(myIntent);
                }
                else
                {
                    txtErr.setVisibility(View.VISIBLE);

                }
            }
        });


    }
}
