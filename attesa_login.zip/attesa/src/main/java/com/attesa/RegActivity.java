package com.attesa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegActivity extends AppCompatActivity {

    DatabaseHelper db;

    EditText etEmail;
    EditText etPass;
    EditText etCPass;
    Button btnRegister;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DatabaseHelper(this);

        etEmail = (EditText)findViewById(R.id.etEmail);
        etPass = (EditText)findViewById(R.id.etPass);
        etCPass = (EditText)findViewById(R.id.etPass2);
        btnRegister = (Button)findViewById(R.id.btnRegister);
        btnLogin = (Button)findViewById(R.id.btnLogin);

        btnRegisterClick();
        btnLoginClick();
    }

    private void btnLoginClick()
    {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private void btnRegisterClick()
    {
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strEmail = etEmail.getText().toString();
                String strPass = etPass.getText().toString();
                String strCPass = etCPass.getText().toString();

                if (strEmail.equals("") || strPass.equals("") || strCPass.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "All fields must contain data.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if (strPass.equals(strCPass))
                    {
                        Boolean chkemail = db.chkemail(strEmail); // call DatabaseHelper.java chkemail function(sets a variable based on the return type).
                        if (chkemail == true) // it's true, we dont exist
                        {
                            // Add new user record to Database.
                            Boolean insert = db.insert(strEmail, strCPass);

                            if (insert == true) // Were we successful?
                            {
                                Toast.makeText(getApplicationContext(), "Registeration Succesfull!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Email already exists!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Passwords do not match.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
