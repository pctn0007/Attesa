package com.example.login_database_prototype;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelperUser extends SQLiteOpenHelper {

    public DatabaseHelperUser(Context context) {
        super(context, "Users.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table users(firstname text, lastname text, email text primary key, password text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists users");

    }

    // Inserting in database.
    public boolean insert(String first, String last, String em, String pass){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("firstname", first);
        contentValues.put("lastname", last);
        contentValues.put("email", em);
        contentValues.put("password", pass);
        long ins = db.insert("users", null, contentValues);
        if (ins == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    // Checking if email exists (true - NO; false - YES)
    public Boolean chkemail(String email)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from user where email=?", new String[]{email});

        if (cursor.getCount() > 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    // Checking the email and password (login).
    public Boolean loginSubmit(String em, String pass)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where email = ? and password = ?", new String[]{em, pass});

      if (cursor.getCount() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}