package com.example.login_database_prototype;

/*
    Dariusz Kulpinski - n01164025
    Attesa Login Prototype
    Patient Login Screen
 */

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Patient_Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient__login);

        //Declarations
        final DatabaseHelperUser db;
        db = new DatabaseHelperUser(this);

        Button login = findViewById(R.id.LoginButton);
        Button register = findViewById(R.id.patientRegister);
        final EditText email = findViewById(R.id.emailinput);
        final EditText pass = findViewById(R.id.passinput);

        //THESE ARE TESTING CREDENTIALS USED BY DEFAULT
        Boolean check = db.insert("Handsome", "Dariusz", "test@email.com", "thepassword");
        if(check == false){
            email.setText("Insert Query Failed");
        }
        //---------------------------------------------

        //Logging in with existing account
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String emaillogin = email.getText().toString();
                String passlogin = pass.getText().toString();
                Boolean loginconfirm = db.loginSubmit(emaillogin, passlogin);

                if(loginconfirm == true){ //If Login Succeeds

                    Intent nextact = new Intent(Patient_Login.this, Logged_In.class);
                    nextact.putExtra("LoginType","Patient");
                    startActivity(nextact);
                }
                else { //If Login Fails

                    AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(Patient_Login.this);
                    dlgAlert.setTitle("Login Failure");
                    dlgAlert.setMessage("Incorrect Credentials. Check email or password.");
                    dlgAlert.setPositiveButton("Ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });
                    dlgAlert.create().show();
                }
            }
        });
        //Creating a new Login
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent nextact = new Intent(Patient_Login.this, Patient_Register.class);
                startActivity(nextact);
            }
        });
    }

    //Back Arrow Click Event
    public boolean onOptionsItemSelected(MenuItem item){
        Intent myIntent = new Intent(Patient_Login.this, LoginSelect.class);
        startActivityForResult(myIntent, 0);
        return true;

    }
}
