package com.example.login_database_prototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Logged_In extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged__in);
        Intent intent = this.getIntent();
        String loginID = intent.getStringExtra("LoginType");

        TextView who = findViewById(R.id.log_info);
        who.setText("Logged in as " + loginID);

        Button logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent nextact = new Intent(Logged_In.this, LoginSelect.class);
                startActivity(nextact);
            }
        });

    }
}
