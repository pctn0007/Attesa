package com.example.login_database_prototype;

import android.app.ActionBar;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class Clinic_Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic__login);

        Button login = findViewById(R.id.loginButton);
        Button register = findViewById(R.id.clinicregister);

        //Using an Existing Login
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               Intent nextact = new Intent(Clinic_Login.this, Logged_In.class);
               nextact.putExtra("LoginType","Clinic");
               startActivity(nextact);
            }
        });
        //Creating a new Login
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent nextact = new Intent(Clinic_Login.this, Clinic_Register.class);
                startActivity(nextact);
            }
        });

    }

    //Back Arrow Click Event
    public boolean onOptionsItemSelected(MenuItem item){
        Intent myIntent = new Intent(Clinic_Login.this, LoginSelect.class);
        startActivityForResult(myIntent, 0);
        return true;

    }
}
