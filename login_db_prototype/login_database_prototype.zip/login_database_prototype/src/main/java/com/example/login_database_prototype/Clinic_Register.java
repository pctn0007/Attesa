package com.example.login_database_prototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Clinic_Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic__register);

        Button register = findViewById(R.id.clinicregisteraccept);

        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent nextact = new Intent(Clinic_Register.this, Logged_In.class);
                nextact.putExtra("LoginType","Clinic");
                startActivity(nextact);
            }
        });
    }
}
