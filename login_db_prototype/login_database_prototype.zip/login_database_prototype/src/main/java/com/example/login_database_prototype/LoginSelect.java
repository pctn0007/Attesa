package com.example.login_database_prototype;

/*
 *
 Dariusz Kulpinski - n01164025
 Software Project - Attesa
 --This is the main line for the prototype database system.
 *
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoginSelect extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_select);

        //When the user presses the login as patient button
        Button patient = findViewById(R.id.patient_login);
        patient.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent nextact = new Intent(LoginSelect.this, Patient_Login.class);
                startActivity(nextact);
            }
        });

        //When the user presses the login as patient button
        Button clinic = findViewById(R.id.clinic_login);
        clinic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent nextact2 = new Intent(LoginSelect.this, Clinic_Login.class);
                startActivity(nextact2);
            }
        });

    }
}
